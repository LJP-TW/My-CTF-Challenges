#!/bin/bash
#
exec 2>/dev/null
timeout 60 qemu-aarch64-static /home/give_me_sc/give_me_sc